
**Quick Starter for Ethereum Smart Contracts**

Sample code for a simple Ethereum 